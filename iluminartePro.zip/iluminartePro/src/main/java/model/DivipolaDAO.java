package model;

public class DivipolaDAO {

}
