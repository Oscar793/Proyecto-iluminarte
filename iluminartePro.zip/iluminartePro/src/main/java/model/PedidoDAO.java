package model;

public class PedidoDAO {

}
