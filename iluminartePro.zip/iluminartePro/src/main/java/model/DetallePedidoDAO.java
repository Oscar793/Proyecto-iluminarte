package model;

public class DetallePedidoDAO {

}
