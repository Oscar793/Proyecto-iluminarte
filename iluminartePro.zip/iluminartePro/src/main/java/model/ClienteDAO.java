package model;

public class ClienteDAO {

}
