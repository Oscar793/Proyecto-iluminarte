package model;

public class VendedorDAO {

}
