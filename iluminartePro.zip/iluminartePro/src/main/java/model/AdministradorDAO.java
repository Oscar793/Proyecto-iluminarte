package model;

public class AdministradorDAO {

}
