package model;

public class Divipola {
	
		private int idMubicipioDivipola;
		private String nombreMubicipioDivipola;
		private String nombreDepartamentoDivipola;
		public Divipola(int idMubicipioDivipola, String nombreMubicipioDivipola, String nombreDepartamentoDivipola) {
			super();
			this.idMubicipioDivipola = idMubicipioDivipola;
			this.nombreMubicipioDivipola = nombreMubicipioDivipola;
			this.nombreDepartamentoDivipola = nombreDepartamentoDivipola;
		}
		public int getIdMubicipioDivipola() {
			return idMubicipioDivipola;
		}
		public void setIdMubicipioDivipola(int idMubicipioDivipola) {
			this.idMubicipioDivipola = idMubicipioDivipola;
		}
		public String getNombreMubicipioDivipola() {
			return nombreMubicipioDivipola;
		}
		public void setNombreMubicipioDivipola(String nombreMubicipioDivipola) {
			this.nombreMubicipioDivipola = nombreMubicipioDivipola;
		}
		public String getNombreDepartamentoDivipola() {
			return nombreDepartamentoDivipola;
		}
		public void setNombreDepartamentoDivipola(String nombreDepartamentoDivipola) {
			this.nombreDepartamentoDivipola = nombreDepartamentoDivipola;
		}

		

}
